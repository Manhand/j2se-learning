package com._520it.day1._05_smis.test;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com._520it.day1._05_smis.dao.IStudentDAO;
import com._520it.day1._05_smis.dao.Impl.StudentDAOImpl;
import com._520it.day1._05_smis.domain.Student;

public class IStudentDAOTest {
	// 创建DAO对象
	private IStudentDAO dao = new StudentDAOImpl();
	
	/*
	@Before 
	// 在执行目标测试方法前执行
	public void init() throws Exception {
		dao = new StudentDAOImpl();
	}
	*/

	@Test
	public void testSave() {
		Student stu = new Student("陆小凤",28);
		dao.save(stu);
	}

	@Test
	public void testDelete() {
		dao.delete(9L);
	}

	@Test
	public void testUpdateLongStudent() {
		
	}

	@Test
	public void testUpdateStudent() {
		Student stu= new Student("叶孤城",29);
		stu.setId(9L);   // 主键不可更改
		dao.update(stu);
	}

	@Test
	public void testGet() {
		Student stu = dao.get(1L);
		System.out.println(stu);
	}
	// Student [id=1, name=西门吹雪, age=32]

	@Test
	public void testList() {
		List<Student> list = dao.list();
		for (Student s : list) {
			System.out.println(s);
		}
	}
	// Student [id=1, name=西门吹雪, age=32]
	// Student [id=2, name=乔峰, age=34]
}
