package com._520it.day1._05_smis.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * JDBC的工具类
 * @author NPJ
 *
 */
public class JdbcUtil_bak1 {
	private static String driverClassName = "com.mysql.jdbc.Driver";
	private static String url = "jdbc:mysql:///jdbcdemo";
	private static String username = "root";
	private static String password = "admin";
	
	public JdbcUtil_bak1(){
		
	}
	// 当JdbcUtil的字节码被加载进JVM时,就会执行,并且执行一次
	static {
		try {
			// 1、加载注册驱动
			Class.forName(JdbcUtil_bak1.driverClassName);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static Connection getConn() {
		try {
			
			// 2、获取连接对象
			return DriverManager.getConnection(JdbcUtil_bak1.url,JdbcUtil_bak1.username,JdbcUtil_bak1.password);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	// 关闭资源
	public static void close(Connection conn,Statement st,ResultSet rs) {
		try {
			if (rs != null) {
				rs.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (st != null) {
					st.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (conn != null) {
						conn.close();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
}
