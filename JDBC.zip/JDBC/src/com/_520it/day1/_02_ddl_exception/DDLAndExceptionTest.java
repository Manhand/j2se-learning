package com._520it.day1._02_ddl_exception;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import org.junit.Test;

/*
操作JDBC的步骤口诀:
-->贾琏欲执事:
1:加载注册驱动.
2:获取连接对象.
3:创建/获取语句对象.
4:执行SQL语句.
5:释放资源.
*/


public class DDLAndExceptionTest {
	// 创建一张表
	@Test
	public void testCreateTable() throws Exception {
		// sql语句
		String sql = "CREATE TABLE `t_student` (`id` bigint(20) PRIMARY KEY AUTO_INCREMENT,`name` varchar(20),`age` int(11))";
		
		// 加载注册驱动
		Class.forName("com.mysql.jdbc.Driver");
		
		// 获取连接对象
		Connection conn = DriverManager.getConnection("jdbc:mysql:///jdbcdemo", "root", "admin");
		
		// 创建/获取语句对象
		Statement st = conn.createStatement();
		
		// 执行sql语句
		st.executeUpdate(sql);
		
		// 释放资源
		st.close();
		conn.close();
	}
	
	// 如何正确处理异常
	@Test
	public void testHandleException(){
		// 声明资源的代码
		String sql = "CREATE TABLE `t_student` (`id` bigint(20) PRIMARY KEY AUTO_INCREMENT,`name` varchar(20),`age` int(11))";
		Connection conn = null;
		Statement st = null;
		try {
			// 可能出现异常的代码
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			// 释放资源
			try {
				if (st != null)
					st.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				try {
					if (conn != null)
						conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	// 使用JAVA7的自动资源关闭
	@Test
	public void testHandleExceptionByJava7() throws Exception {
		String sql = "CREATE TABLE `t_student` (`id` bigint(20) PRIMARY KEY AUTO_INCREMENT,`name` varchar(20),`age` int(11))";
		try(// 获取连接对象
			Connection conn = DriverManager.getConnection("jdbc:mysql:///jdbcdemo", "root", "admin");
			
			// 创建/获取语句对象
			Statement st = conn.createStatement();
			) {
			st.executeUpdate(sql);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
