package com._520it.day1._05_smis.domain;

/**
 * // 描述學生對象
 * @author NPJ
 *
 */
public class Student {
	private Long    id; 	// 唯一标识
	private String  name;   // 学生姓名
	private Integer age;    // 学生年龄
	
	public Student() {
		super();
	}

	public Student(String name, Integer age) {
		super();
		this.name = name;
		this.age = age;
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", age=" + age + "]";
	}
	
	
}
