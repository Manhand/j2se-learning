package com._520it.day1._05_smis.dao;

import java.util.List;

import com._520it.day1._05_smis.domain.Student;

/**
 * 定义学生对象的CRUD操作
 * @author NPJ
 *
 */
public interface IStudentDAO {
	
	/**
	 * 保存指定的学生对象
	 * @param stu 需要保存的学生对象	
	 */
	void save(Student stu);
	
	/**
	 * 删除指定id的学生对象
	 * @param id 需要被删除的学生id
	 */
	void delete(Long id);
	
	/**
	 * 更新指定id的学生对象
	 * @param id 需要被修改的学生id
	 * @param newStu 新的Student对象数据
	 */
	void update(Long id,Student newStu);
	
	/**
	 * 更新指定id的学生对象
	 * @param newStu 新的Student对象数据(该对象包含id)
	 */
	void update(Student newStu);
	
	/**
	 * 查询指定id的学生对象
	 * @param id 需要查询的学生id
	 * @return   如果该id对应的学生对象存在则返回该对象,否则则返回null
	 */
	Student get(Long id);
	
	/**
	 * 查询所有的学生对象
	 * @return 非空则返回所有的学生对象集合,否则则返回一个空集(new ArrayList<Student>())
	 */
	List<Student> list();
}
