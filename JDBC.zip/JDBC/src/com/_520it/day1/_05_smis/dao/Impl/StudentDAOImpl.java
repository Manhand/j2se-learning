package com._520it.day1._05_smis.dao.Impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com._520it.day1._05_smis.dao.IStudentDAO;
import com._520it.day1._05_smis.domain.Student;
import com._520it.day1._05_smis.util.JdbcUtil;

public class StudentDAOImpl implements IStudentDAO {
	
	@Override
	// INSERT INTO t_student (name,age) VALUES('xxx',23);
	public void save(Student stu) {
		StringBuilder sb = new StringBuilder(80);
		sb.append("INSERT INTO t_student (name,age) VALUES(");
		sb.append("'").append(stu.getName()).append("'").append(",");
		sb.append(stu.getAge());
		sb.append(")");
		System.out.println(sb);
		Connection conn = null;
		Statement st = null;
		try {
			// 1+2、加載注册驱动并获得连接对象
			conn = JdbcUtil.getConn();
			// 3、获取/创建语句对象
			st = conn.createStatement();
			// 4、执行sql语句
			st.executeUpdate(sb.toString());
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, st, null);
		}
	}

	@Override
	public void delete(Long id) {
		// TODO Auto-generated method stub
		String sql = "DELETE FROM t_student WHERE id = " + id;
		Connection conn = null;
		Statement st = null;
		try {
			// 1+2、加載注册驱动并获得连接对象
			conn = JdbcUtil.getConn();
			// 3、获取/创建语句对象
			st = conn.createStatement();
			// 4、执行sql语句
			st.executeUpdate(sql);
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, st, null);
		}
	}

	@Override
	// UPDATE t_student SET name = 'xxx',age = xx WHERE id = x;
	public void update(Long id, Student newStu) {
		// TODO Auto-generated method stub
		StringBuilder sb = new StringBuilder(80);
		sb.append("UPDATE t_student SET name = ");
		sb.append("'").append(newStu.getName()).append("'");
		sb.append(",age = ").append(newStu.getAge());
		sb.append("WHERE id = ").append(id);
		System.out.println(sb);
		System.out.println(sb);
		Connection conn = null;
		Statement st = null;
		try {
			// 1+2、加載注册驱动并获得连接对象
			conn = JdbcUtil.getConn();
			// 3、获取/创建语句对象
			st = conn.createStatement();
			// 4、执行sql语句
			st.executeUpdate(sb.toString());
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, st, null);
		}
	}

	@Override
	// UPDATE t_student SET name = 'xxx',age = xx WHERE id = x;
	public void update(Student newStu) {
		// TODO Auto-generated method stub
		StringBuilder sb = new StringBuilder(80);
		sb.append("UPDATE t_student SET name = ");
		sb.append("'").append(newStu.getName()).append("'");
		sb.append(",age = ").append(newStu.getAge());
		sb.append(" WHERE id = ").append(newStu.getId());
		System.out.println(sb);
		Connection conn = null;
		Statement st = null;
		
		try {
			// 1+2、加載注册驱动并获得连接对象
			conn = JdbcUtil.getConn();
			// 3、获取/创建语句对象
			st = conn.createStatement();
			// 4、执行sql语句
			st.executeUpdate(sb.toString());
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, st, null);
		}
	}

	@Override
	public Student get(Long id) {
		String sql = "SELECT * FROM t_student WHERE id = " + id;
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		Student stu = null;
		try {
			// 1+2、加載注册驱动并获得连接对象
			conn = JdbcUtil.getConn();
			// 3、获取/创建语句对象
			st = conn.createStatement();
			// 4、执行sql语句
			rs = st.executeQuery(sql);
			if (rs.next()) {
				stu = new Student();
				Long sid = rs.getLong("id");
				String name = rs.getString("name");
				Integer age = rs.getInt("age");
				stu.setId(sid);
				stu.setName(name);
				stu.setAge(age);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			JdbcUtil.close(conn, st, rs);
		}
		return stu;
	}

	@Override
	public List<Student> list() {
		String sql = "SELECT * FROM t_student";
		List<Student> list = new ArrayList<>();
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		try {	
			// 1+2、加載注册驱动并获得连接对象
			conn = JdbcUtil.getConn();
			// 3、获取/创建语句对象
			st = conn.createStatement();
			// 4、执行sql语句
			rs = st.executeQuery(sql);
			// 处理结果集
			while (rs.next()) {
				Student stu = new Student();
				list.add(stu);
				Long id = rs.getLong("id");
				String name = rs.getString("name");
				Integer age = rs.getInt("age");
				stu.setId(id);
				stu.setName(name);
				stu.setAge(age);
			}
		} catch (Exception e) {

		} finally {
			JdbcUtil.close(conn, st, rs);
		}

		return list;
	}

}
