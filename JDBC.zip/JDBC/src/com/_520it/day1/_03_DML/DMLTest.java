package com._520it.day1._03_DML;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import org.junit.Test;

// JDBC的DML操作
public class DMLTest {
	// 向t_student插入 西门吹雪 32
	@Test
	public void testInsert() throws Exception {
		String sql = "INSERT INTO t_student (name,age) VALUES('西门吹雪',32)";
		// 加载注册驱动
		Class.forName("com.mysql.jdbc.Driver");
		
		// 获取连接对象
		Connection conn = DriverManager.getConnection("jdbc:mysql:///jdbcdemo","root","admin");
		
		// 创建/获取语句对象
		Statement st = conn.createStatement();
		
		// 执行sql语句
		st.executeUpdate(sql);
		
		// 释放资源
		st.close();
		conn.close();
	}
	
	// 需求：将id为2的名字改为乔峰,34岁
	@Test
	public void testUpdate() throws Exception {
		String sql = "UPDATE t_student set name = '乔峰', age = 34 WHERE id = 2";
		// 加载注册驱动
		Class.forName("com.mysql.jdbc.Driver");
	
		// 获取连接对象
		Connection conn = DriverManager.getConnection("jdbc:mysql:///jdbcdemo","root","admin");
		
		// 创建/获取语句对象
		Statement st = conn.createStatement();
		
		// 执行sql语句
		st.executeUpdate(sql);
		
		// 释放资源
		st.close();
		conn.close();
	}
	
	// 需求：删除id为2的学生信息
	@Test
	public void testDelete() throws Exception {
		String sql = "DELETE FROM t_student WHERE id = 2";
		// 加载注册驱动
		Class.forName("com.mysql.jdbc.Driver");
		
		// 获取连接对象
		Connection conn = DriverManager.getConnection("jdbc:mysql:///jdbcdemo", "root", "admin");
		
		// 创建/获取语句对象
		Statement st = conn.createStatement();
		
		// 执行sql语句
		st.executeUpdate(sql);
		
		// 释放资源
		st.close();
		conn.close();
	}
}
