package com._520it.day1._01_connection;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.DriverManager;

import org.junit.Test;

/*操作步骤(贾琏):
1):加载注册驱动.
   Class.forName("com.mysql.jdbc.Driver");
   为什么说上述代码,在完成加载注册驱动?
   上述代码:
          1):把com.mysql.jdbc.Driver这一份字节码加载进JVM.
          2):当一份字节码被加载进JVM,就会执行其静态代码块.
              而其底层的静态代码块在完成注册驱动工作.
2):获取连接对象.
   通过DriverManager的getConnection方法创建Connection对象.
   Connection  conn = DriverManager.getConnection(url,username,password);
      url=jdbc:mysql://localhost:3306/jdbcdemo
        如果连接的是本机的MySQL,并且端口是默认的3306,则可以简写:
      url=jdbc:mysql:///jdbcdemo
      username=root
      password=admin
可以通过 show processlist命令来查看有几个MySQL进程.*/

public class ConnectionTest {
	@Test
	public void testName() throws Exception {
		// 加载注册驱动
		Class.forName("com.mysql.jdbc.Driver");
		// 获取连接对象
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/jdbcdemo", "root", "admin");
		Thread.sleep(5000);
	}
	
	public void testName2() throws Exception {
		// 加载注册驱动
		// Class.forName("com.mysql.jdbc.Driver");
		// 获取连接对象
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/jdbcdemo", "root", "admin");
		Thread.sleep(5000);
	}
}
