package com._520it.day1._04_DQL;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.junit.Test;

/*  1、    boolean next():判断当前光标是否能向下移动,如果能向下移动返回true,并同时将光标移动到下一行.
	2、	
		Xxx getXxx(int columnIndex):取出当前光标所在行的第columnIndex列的数据(columnIndex从1开始算).
	    Xxx getXxx(String columnName):取出当前光标所在行的列名为columnName列的数据,columnName可以是别名.
	    Xxx表示数据类型,比如String,int,long,Date等. 推荐使用列名来取数据.
*/
public class DQLTest {
	// 迭代器
	@Test
	public void testIterator() throws Exception {
		List<String> list = Arrays.asList("A", "B", "C", "D");
		Iterator it = list.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}
	}

	// 需求1：查询product表中有多少条数据
	/*mysql> select count(id) from product;
	+-----------+
	|   count   |
	+-----------+
	|        21 |
	+-----------+
	1 row in set
	 */
	@Test
	public void testQueryCount() throws Exception {
		String sql = "SELECT COUNT(id) count FROM product";

		// 加载注册驱动
		Class.forName("com.mysql.jdbc.Driver");

		// 获取连接对象
		Connection conn = DriverManager.getConnection("jdbc:mysql:///jdbcDemo", "root", "admin");

		// 创建/获取语句对象
		Statement st = conn.createStatement();

		// 执行sql语句
		ResultSet rs = st.executeQuery(sql);
		if (rs.next()) {
			// System.out.println(rs.getInt(1)); 		// 21
			System.out.println(rs.getInt("count")); // 21

		}
		// 释放资源
		rs.close();
		st.close();
		conn.close();
	}

	// 需求2：查询id为10的商品信息
	/*	
	    mysql> SELECT * FROM product WHERE id = 10;
		+----+-------------+--------+-----------+----------+-------+--------+-----------+
		| id | productName | dir_id | salePrice | supplier | brand | cutoff | costPrice |
		+----+-------------+--------+-----------+----------+-------+--------+-----------+
		| 10 | 罗技M310    |      2 |       135 | 罗技     | 罗技  |   0.92 |      69.8 |
		+----+-------------+--------+-----------+----------+-------+--------+-----------+
		1 row in set
	*/
	@Test
	public void testQuerySingle() throws Exception {
		String sql = "SELECT * FROM product WHERE id = 10";
		// 加载注册驱动
		Class.forName("com.mysql.jdbc.Driver");

		// 获取连接对象
		Connection conn = DriverManager.getConnection("jdbc:mysql:///jdbcDemo", "root", "admin");

		// 创建/获取语句对象
		Statement st = conn.createStatement();

		// 执行sql语句
		ResultSet rs = st.executeQuery(sql);
		if (rs.next()) {
			long id = rs.getLong("id");
			String productName = rs.getString("productName");
			Double salePrice = rs.getDouble("salePrice");
			System.out.println(id + "," + productName + "," + salePrice); // 10,罗技M310,135.0
		}
		// 释放资源
		rs.close();
		st.close();
		conn.close();
	}

	// 需求3：获取product表中所有的商品信息
	@Test
	public void testQueryAll() throws Exception {
		String sql = "SELECT * FROM product";
		// 加载注册驱动
		Class.forName("com.mysql.jdbc.Driver");

		// 获取连接对象
		Connection conn = DriverManager.getConnection("jdbc:mysql:///jdbcDemo", "root", "admin");

		// 创建/获取语句对象
		Statement st = conn.createStatement();

		// 执行sql语句
		ResultSet rs = st.executeQuery(sql);
		while(rs.next()) {
			long id = rs.getLong("id");
			String productName = rs.getString("productName");
			Double salePrice = rs.getDouble("salePrice");
			System.out.println(id + " " + productName + " " + salePrice); // 10,罗技M310,135.0
		}
		// 释放资源
		rs.close();
		st.close();
		conn.close();
	}
	/*
	1 罗技M90 90.0
	2 罗技M100 49.0
	3 罗技M115 99.0
	4 罗技M125 80.0
	5 罗技木星轨迹球 182.0
	6 罗技火星轨迹球 460.68
	7 罗技G9X 897.6
	8 罗技M215 89.0
	9 罗技M305 119.0
	10 罗技M310 135.0
	11 罗技M505 148.0
	12 罗技M555 275.0
	13 罗技M905 549.6
	14 罗技MX1100 660.0
	15 罗技M950 813.6
	16 罗技MX Air 1558.8
	17 罗技G1 155.0
	18 罗技G3 229.0
	19 罗技G500 478.8
	20 罗技G700 838.8
	21 罗技G700 838.8
	*/
}
